# authenticating-react-app
learning how to authenticate an user and to provide or deny any access to the protected data based on their authentication
